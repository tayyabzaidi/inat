<?php
$__dt_buttons_group = '<div class="btn-group  btn-group-sm" role="group" aria-label="Category Options" >'
        . '<button  dt_btn_action="edit"    type="button" class="btn btn-sm btn-primary" style="font-size:12px;"> <i class="fa fa-edit"></i> Edit</button>'
        . '</div>';
?>
<script>
    console.log('dashboard root script init....');
</script>